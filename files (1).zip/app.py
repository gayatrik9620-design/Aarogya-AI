"""MedCheck: Dose-Timing & Meal/Side-Effect Check-In Assistant. Run: streamlit run app.py"""
from datetime import date, time

import streamlit as st

import agent
import charts
import database as db
from config import APP_NAME, DISCLAIMER, FOOD_RULES, GOOGLE_API_KEY, MEAL_OPTIONS, SYMPTOMS

st.set_page_config(page_title=APP_NAME, page_icon="💜", layout="wide")
db.init_db()

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;700;800&display=swap');
html, body, [class*="css"], .stApp { font-family: 'Plus Jakarta Sans', sans-serif; color: #efeaff; }
.stApp { background: radial-gradient(1100px 600px at 10% -10%, #6d28d9 0%, transparent 60%),
         radial-gradient(900px 600px at 100% 0%, #c026d3 0%, transparent 55%),
         linear-gradient(160deg, #1b1033 0%, #2a1457 55%, #3b1b7a 100%); background-attachment: fixed; }
header[data-testid="stHeader"] { background: transparent; }
.block-container { padding-top: 1.6rem; max-width: 1150px; }
.glass { background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.18); border-radius: 20px;
         padding: 1.1rem 1.3rem; backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
         box-shadow: 0 8px 30px rgba(20,5,50,0.35); margin-bottom: 0.9rem; }
.metric-label { font-size: .85rem; color: #d8ccff; }
.metric-value { font-size: 2rem; font-weight: 800; line-height: 1.1; }
.pill { display:inline-block; padding: 2px 12px; border-radius: 999px; font-size: .78rem; font-weight: 700; }
.pill.taken { background: rgba(167,139,250,.30); } .pill.pending { background: rgba(255,255,255,.14); }
.pill.skipped, .pill.missed { background: rgba(240,171,252,.30); }
h1, h2, h3 { color: #fff; letter-spacing: -0.01em; }
.stTabs [data-baseweb="tab-list"] { gap: 6px; background: rgba(255,255,255,.07); padding: 6px; border-radius: 16px; }
.stTabs [data-baseweb="tab"] { border-radius: 12px; padding: 8px 16px; color: #d8ccff; }
.stTabs [aria-selected="true"] { background: linear-gradient(135deg,#8b5cf6,#c026d3); color: #fff; }
.stTabs [data-baseweb="tab-highlight"], .stTabs [data-baseweb="tab-border"] { display: none; }
.stButton > button, .stDownloadButton > button, .stFormSubmitButton > button {
  background: linear-gradient(135deg,#8b5cf6,#a855f7); color: #fff; border: 1px solid rgba(255,255,255,.25);
  border-radius: 12px; font-weight: 700; }
.stButton > button:hover, .stFormSubmitButton > button:hover { border-color: #fff; filter: brightness(1.1); }
.stButton > button:focus-visible { outline: 2px solid #fff; }
[data-testid="stSidebar"] { display: none; }
.disclaimer { font-size: .8rem; color: #cfc2ff; text-align: center; margin-top: 1.5rem; }
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)


def metric(label, value, sub=""):
    st.markdown(f'<div class="glass"><div class="metric-label">{label}</div>'
                f'<div class="metric-value">{value}</div><div class="metric-label">{sub}</div></div>',
                unsafe_allow_html=True)


def flash(level, msg):
    {"ok": st.success, "info": st.info, "warn": st.warning}[level](msg)


# ---------- Header ----------
mode = "Gemini connected" if GOOGLE_API_KEY else "Demo mode (no API key)"
st.markdown(f"# 💜 {APP_NAME}")
st.caption(f"Dose timing, meal and side-effect check-ins. Assistant: {mode}")

tabs = st.tabs(["Overview", "Today's doses", "Check-in", "Wellness", "Medicines", "Assistant", "Export"])
sched = db.today_schedule()

# ---------- Overview ----------
with tabs[0]:
    taken = int((sched["status"] == "taken").sum())
    wl = db.get_wellness(1)
    today_row = wl[wl["log_date"] == str(date.today())]
    steps = int(today_row["steps"].iloc[0]) if not today_row.empty else 0
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric("7-day adherence", f"{db.adherence_pct(7)}%", "doses taken on record")
    with c2: metric("Today", f"{taken}/{len(sched)}", "doses taken")
    with c3: metric("Steps today", f"{steps:,}", "log them in Wellness")
    with c4: metric("Medicines", len(sched), "active")
    a, b = st.columns([3, 2])
    a.plotly_chart(charts.adherence_by_day(), use_container_width=True)
    b.plotly_chart(charts.status_mix(), use_container_width=True)
    a, b = st.columns(2)
    a.plotly_chart(charts.adherence_by_med(), use_container_width=True)
    b.plotly_chart(charts.steps_chart(), use_container_width=True)

# ---------- Today's doses ----------
with tabs[1]:
    st.subheader("Today's schedule")
    if sched.empty:
        st.info("No medicines yet. Add one in the Medicines tab.")
    for _, r in sched.iterrows():
        st.markdown(f'<div class="glass"><b>{r["schedule_time"]} · {r["name"]}</b> {r["dose"]} '
                    f'<span class="pill {r["status"]}">{r["status"]}</span><br>'
                    f'<span class="metric-label">{FOOD_RULES.get(r["food_rule"], "Any time")}. {r["notes"] or ""}</span></div>',
                    unsafe_allow_html=True)
        c1, c2, c3, c4 = st.columns([2, 1, 1, 3])
        meal = c1.selectbox("Food context", MEAL_OPTIONS, key=f"meal{r['id']}", label_visibility="collapsed")
        if c2.button("Taken", key=f"t{r['id']}"):
            db.log_dose(int(r["id"]), "taken", meal)
            st.session_state[f"msg{r['id']}"] = agent.timing_check(r["food_rule"], meal, r["schedule_time"])
            st.rerun()
        if c3.button("Skipped", key=f"s{r['id']}"):
            db.log_dose(int(r["id"]), "skipped")
            st.session_state[f"msg{r['id']}"] = ("info", "Skipped dose logged. Ask your doctor what to do if you skip often.")
            st.rerun()
        if f"msg{r['id']}" in st.session_state:
            flash(*st.session_state[f"msg{r['id']}"])
        c4.caption(f"Note: {agent.med_note(r['name'])}")

# ---------- Check-in ----------
with tabs[2]:
    st.subheader("How are you feeling?")
    meds = db.get_meds()
    with st.form("checkin", clear_on_submit=True):
        c1, c2 = st.columns(2)
        med_name = c1.selectbox("Medicine", ["General"] + list(meds["name"]))
        meal = c2.selectbox("Meal timing", MEAL_OPTIONS)
        symptom = c1.selectbox("Comfort or side effect", SYMPTOMS)
        severity = c2.slider("How strong? (1 mild, 5 severe)", 1, 5, 1)
        note = st.text_input("Note (optional)")
        if st.form_submit_button("Save check-in"):
            mid = None if med_name == "General" else int(meds[meds["name"] == med_name]["id"].iloc[0])
            db.add_checkin(mid, meal, symptom, severity, note)
            st.success("Check-in saved.")
            if symptom != "None":
                flash("warn" if severity >= 3 else "info", agent.severity_advice(severity))
    a, b = st.columns([3, 2])
    a.dataframe(db.get_checkins(20), use_container_width=True, hide_index=True)
    b.plotly_chart(charts.symptom_chart(), use_container_width=True)

# ---------- Wellness ----------
with tabs[3]:
    st.subheader("Daily wellness log")
    with st.form("wellness"):
        c1, c2, c3, c4 = st.columns(4)
        day = c1.date_input("Date", date.today())
        steps_in = c2.number_input("Steps", 0, 100000, 5000, 500)
        water = c3.number_input("Water (ml)", 0, 10000, 2000, 250)
        sleep = c4.number_input("Sleep (hrs)", 0.0, 24.0, 7.0, 0.5)
        notes = st.text_input("Health notes")
        if st.form_submit_button("Save log"):
            db.save_wellness(day, steps_in, water, sleep, notes)
            st.success("Wellness log saved.")
    a, b = st.columns(2)
    a.plotly_chart(charts.steps_chart(), use_container_width=True)
    b.plotly_chart(charts.sleep_water_chart(), use_container_width=True)
    st.dataframe(db.get_wellness(30).sort_values("log_date", ascending=False), use_container_width=True, hide_index=True)

# ---------- Medicines ----------
with tabs[4]:
    st.subheader("Your medicines")
    with st.form("addmed", clear_on_submit=True):
        c1, c2, c3, c4 = st.columns(4)
        name = c1.text_input("Name")
        dose = c2.text_input("Dose", placeholder="500 mg")
        t = c3.time_input("Time", time(8, 0))
        rule = c4.selectbox("Food rule", list(FOOD_RULES), format_func=FOOD_RULES.get)
        notes = st.text_input("Notes (optional)")
        if st.form_submit_button("Add medicine"):
            if name.strip():
                db.add_med(name, dose, t.strftime("%H:%M"), rule, notes)
                st.rerun()
            else:
                st.error("Enter a medicine name.")
    for _, r in db.get_meds().iterrows():
        c1, c2 = st.columns([5, 1])
        c1.markdown(f'<div class="glass"><b>{r["name"]}</b> {r["dose"]} at {r["schedule_time"]} · '
                    f'{FOOD_RULES.get(r["food_rule"], "Any time")}</div>', unsafe_allow_html=True)
        if c2.button("Remove", key=f"rm{r['id']}"):
            db.remove_med(int(r["id"]))
            st.rerun()

# ---------- Assistant ----------
with tabs[5]:
    st.subheader("Ask the health assistant")
    quick = ["Should I take metformin before or after food?", "What if I miss a dose?", "Why might I feel drowsy after medicines?"]
    cols = st.columns(len(quick))
    for col, text in zip(cols, quick):
        if col.button(text, key=text):
            st.session_state["question"] = text
    question = st.text_area("Your question", key="question", placeholder="e.g. Can I take vitamin D3 on an empty stomach?")
    if st.button("Ask") and question.strip():
        with st.spinner("Thinking..."):
            answer, used = agent.ask_assistant(question, db.get_meds(), db.adherence_pct(7))
        st.markdown(f'<div class="glass"><span class="pill taken">{used}</span><br><br>{answer}</div>', unsafe_allow_html=True)

# ---------- Export ----------
with tabs[6]:
    st.subheader("Export your data")
    for kind, label in [("doses", "Medication history"), ("wellness", "Wellness logs"), ("checkins", "Side-effect check-ins")]:
        c1, c2, c3 = st.columns([3, 1, 1])
        c1.markdown(f"**{label}**")
        c2.download_button("CSV", db.export_data(kind, "csv"), f"{kind}.csv", "text/csv", key=f"{kind}c")
        c3.download_button("JSON", db.export_data(kind, "json"), f"{kind}.json", "application/json", key=f"{kind}j")

st.markdown(f'<div class="disclaimer">⚕️ {DISCLAIMER}</div>', unsafe_allow_html=True)
